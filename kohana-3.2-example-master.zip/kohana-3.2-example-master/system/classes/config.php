<?php defined('SYSPATH') or die('No direct script access.');

class Config extends Kohana_Config {}