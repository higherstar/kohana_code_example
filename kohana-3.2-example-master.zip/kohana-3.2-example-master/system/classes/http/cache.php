<?php defined('SYSPATH') or die('No direct script access.');

class HTTP_Cache extends Kohana_HTTP_Cache {}