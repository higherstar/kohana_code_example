<?php defined('SYSPATH') or die('No direct script access.');

abstract class Request_Client_External extends Kohana_Request_Client_External {}