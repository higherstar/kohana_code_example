<?php defined('SYSPATH') or die('No direct script access.');

class Valid extends Kohana_Valid {}
