<?php defined('SYSPATH') or die('No direct script access.');

class HTML extends Kohana_HTML {}