<?php defined('SYSPATH') or die('No direct script access.');

class Num extends Kohana_Num {}
