<?php defined('SYSPATH') or die('No direct script access.');

class CLI extends Kohana_CLI {}