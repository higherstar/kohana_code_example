Making a template driven site.

<http://kerkness.ca/wiki/doku.php?id=template-site:create_the_template>
	
<http://kerkness.ca/wiki/doku.php?id=template-site:extending_the_template_controller>

<http://kerkness.ca/wiki/doku.php?id=template-site:basic_page_controller>