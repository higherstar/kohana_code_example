﻿<?php defined('SYSPATH') or die('No direct script access.');

return array(
    'Hello World' => 'Bonjour le monde !',
	'en' => 'Anglais',
    'fr' => 'Français',
    'jp' => 'Japonais',
    'Create an account' => 'Créer un compte',
    'Login' => 'Se connecter',
    'Logout' => 'Se déconnecter',
    'ABOUT'	=> 'À PROPOS',
	'FAQ'	=> 'FAQ',
	':field must not be empty'		=> ':field ne doit pas être vide',
	'user.password.pwdneusr'		=> 'Ne doit pas être le même...',
);