<?php defined('SYSPATH') or die('No direct script access.');

return array(
    'Hello World' => 'こんいちはみなさん',
    'en' => 'えいご',
    'fr' => 'ふらんすご',
    'jp' => 'にほんご',
    'Create an account' => 'あこんと',
    'Login' => 'ろぎんぐ',
    'Logout' => 'ろぎのうと',
    'ABOUT'	=> 'あばと',
	'FAQ'	=> 'ふぁく',
	':field must not be empty'		=> ':field ない',
	'user.password.pwdneusr'		=> 'おなじだめ',
);